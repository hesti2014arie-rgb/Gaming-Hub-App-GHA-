package com.example.gaminghub

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.gaminghub.databinding.ActivityMainBinding
import rikka.shizuku.Shizuku
import java.io.DataOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val SHIZUKU_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRecorder.setOnClickListener {
            Toast.makeText(this, "Fitur Recorder dikunci sementara untuk fokus tes HBG", Toast.LENGTH_SHORT).show()
        }
        binding.btnChat.setOnClickListener {
            Toast.makeText(this, "Fitur Chat WebSocket dikunci sementara untuk fokus tes HBG", Toast.LENGTH_SHORT).show()
        }

        binding.btnExecuteHbg.setOnClickListener {
            checkAndRunHbg()
        }
    }

    private fun checkAndRunHbg() {
        if (Shizuku.pingBinder()) {
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                showExtremePerformanceWarning()
            } else {
                Shizuku.requestPermission(SHIZUKU_CODE)
            }
        } else {
            Toast.makeText(this, "Shizuku tidak aktif! Silakan buka aplikasi Shizuku terlebih dahulu.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showExtremePerformanceWarning() {
        AlertDialog.Builder(this)
            .setTitle("⚠️ PERINGATAN KINERJA EKSTREM")
            .setMessage("Aplikasi ini akan memeras kapasitas CPU hingga batas maksimal dan berpotensi membuat perangkat menjadi panas. Segala risiko kerusakan hardware atau penurunan kesehatan baterai ditanggung penuh oleh pengguna!")
            .setCancelable(false)
            .setPositiveButton("SAYA SETUJU & LANJUTKAN") { _, _ ->
                runHbgOptimization()
            }
            .setNegativeButton("BATAL") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun runHbgOptimization() {
        try {
            val process = Shizuku.newProcess(arrayOf("sh"), null, null)
            val os = DataOutputStream(process.outputStream)
            
            os.writeBytes("echo performance > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor\n")
            os.writeBytes("setprop debug.egl.hw 1\n")
            os.writeBytes("setprop debug.sf.hw 1\n")
            os.writeBytes("exit\n")
            os.flush()

            process.waitFor()
            binding.txtStatusHbg.text = "Status HBG: AKTIF (Mode Performa Ekstrem)"
            Toast.makeText(this, "Optimasi HBG Berhasil Diterapkan!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menerapkan tweak: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
