plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.gaminghub"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.gaminghub"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(libs.androidx-core-ktx)
    implementation(libs.androidx-appcompat)
    implementation(libs.material)
    implementation(libs.androidx-constraintlayout)
    implementation(libs.shizuku.api)
    implementation(libs.shizuku.provider)
}
