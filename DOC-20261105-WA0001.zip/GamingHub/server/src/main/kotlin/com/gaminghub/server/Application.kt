package com.gaminghub.server

import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.routing.*
import io.ktor.server.websocket.*
import io.ktor.websocket.*
import java.time.Duration
import java.util.concurrent.atomic.AtomicInteger

class Connection(val session: DefaultWebSocketSession, val name: String)

fun main() {
    embeddedServer(Netty, port = 8080, host = "0.0.0.0", module = Application::module)
        .start(wait = true)
}

fun Application.module() {
    install(WebSockets) {
        pingPeriod = Duration.ofSeconds(15)
        timeout = Duration.ofSeconds(30)
        maxFrameSize = Long.MAX_VALUE
        masking = false
    }

    val connections = LinkedHashSet<Connection>()
    val counter = AtomicInteger(0)

    suspend fun broadcast(message: String) {
        val targets = synchronized(connections) { connections.toList() }
        targets.forEach { runCatching { it.session.send(Frame.Text(message)) } }
    }

    routing {
        webSocket("/chat") {
            val name = call.request.queryParameters["name"]
                ?.trim()?.take(20)?.takeIf { it.isNotEmpty() }
                ?: "Gamer${counter.incrementAndGet()}"

            val me = Connection(this, name)
            synchronized(connections) { connections += me }
            broadcast("📢 $name bergabung")

            try {
                for (frame in incoming) {
                    if (frame !is Frame.Text) continue
                    val text = frame.readText().trim().take(500)
                    if (text.isNotEmpty()) broadcast("$name: $text")
                }
            } finally {
                synchronized(connections) { connections -= me }
                broadcast("📢 $name keluar")
            }
        }
    }
}
