rootProject.name = "gaming-hub-server"
