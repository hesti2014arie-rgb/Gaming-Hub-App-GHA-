# Gaming Hub

Aplikasi Android (Kotlin + Jetpack Compose).

## Status fitur
| Fitur | Status |
|---|---|
| HBG (Helper Boost Game) | Aktif, via Shizuku |
| Recorder Layar | Dikunci |
| Chat (WebSocket) | Dikunci (kode sudah ada) |

Saklar fitur: `app/src/main/java/com/gaminghub/Features.kt`.

## Build APK lewat GitHub
1. Upload isi folder ini ke repo GitHub (branch `main`).
2. Buka tab **Actions**, workflow **Build Gaming Hub APK** jalan otomatis (atau klik *Run workflow*).
3. Setelah selesai, unduh artifact **Gaming_Hub-V1** → isinya `Gaming_Hub-V1.apk`.

## Tes HBG dengan Shizuku
1. Install aplikasi Shizuku dan jalankan (wireless debugging atau root).
2. Buka Gaming Hub → tab HBG → setujui peringatan.
3. Tekan **Minta izin Shizuku**, izinkan. Status jadi 🟢.
4. Atur opsi, tekan **Terapkan**. Hasil tiap perintah tampil di bawah.
5. Kalau layar atau tampilan aneh, tekan **Reset semua**.
   Cadangan lewat ADB: `adb shell wm size reset && adb shell wm density reset`

## Server chat (nanti)
Folder `server/` berisi server Ktor WebSocket (`gradle run`), lalu `CHAT_ENABLED = true`.
