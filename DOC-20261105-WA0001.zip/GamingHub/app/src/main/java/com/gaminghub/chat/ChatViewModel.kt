package com.gaminghub.chat

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUiState(
    val connected: Boolean = false,
    val status: String = "Belum terhubung",
    val messages: List<String> = emptyList()
)

class ChatViewModel(
    private val client: ChatClient = ChatClient()
) : ViewModel() {

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            client.events.collect { event ->
                _state.update { s ->
                    when (event) {
                        ChatEvent.Connected -> s.copy(connected = true, status = "Terhubung")
                        is ChatEvent.Message -> s.copy(messages = s.messages + event.text)
                        is ChatEvent.Disconnected -> s.copy(connected = false, status = event.reason)
                    }
                }
            }
        }
    }

    // 10.0.2.2 = localhost laptop saat pakai emulator Android.
    // HP asli: ganti dengan IP laptop, misalnya 192.168.1.10
    fun connect(name: String, host: String = "10.0.2.2") {
        _state.update { it.copy(status = "Menghubungkan...") }
        client.connect("ws://$host:8080/chat?name=${Uri.encode(name)}")
    }

    fun send(text: String) {
        if (text.isNotBlank()) client.send(text.trim())
    }

    override fun onCleared() {
        client.disconnect()
    }
}
