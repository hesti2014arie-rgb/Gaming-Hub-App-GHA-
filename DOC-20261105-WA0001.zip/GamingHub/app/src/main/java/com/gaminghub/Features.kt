package com.gaminghub

/** Saklar fitur. Ubah ke true kalau fiturnya sudah siap. */
object Features {
    const val HBG_ENABLED = true
    const val RECORDER_ENABLED = false   // dikunci dulu
    const val CHAT_ENABLED = false       // dikunci dulu
}
