package com.gaminghub.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.gaminghub.Features
import com.gaminghub.chat.ChatScreen

enum class Tab(val label: String, val icon: String, val enabled: Boolean) {
    HOME("Beranda", "🏠", true),
    RECORDER("Recorder", "🎥", Features.RECORDER_ENABLED),
    CHAT("Chat", "💬", Features.CHAT_ENABLED),
    HBG("HBG", "🚀", Features.HBG_ENABLED)
}

@Composable
fun GamingHubApp() {
    var current by rememberSaveable { mutableStateOf(Tab.HOME) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = current == tab,
                        onClick = { current = tab },
                        icon = { Text(if (tab.enabled) tab.icon else "🔒") },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { inner ->
        val m = Modifier.padding(inner)
        when (current) {
            Tab.HOME -> HomeScreen(m)
            Tab.RECORDER -> LockedScreen("Recorder Layar", m)   // belum dibuat
            Tab.CHAT -> if (Features.CHAT_ENABLED) ChatScreen() else LockedScreen("Chat", m)
            Tab.HBG -> HbgScreen(m)
        }
    }
}
