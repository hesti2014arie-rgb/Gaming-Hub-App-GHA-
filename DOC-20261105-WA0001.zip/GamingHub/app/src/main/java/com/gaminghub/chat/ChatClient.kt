package com.gaminghub.chat

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit

sealed interface ChatEvent {
    data object Connected : ChatEvent
    data class Message(val text: String) : ChatEvent
    data class Disconnected(val reason: String) : ChatEvent
}

class ChatClient {
    private val http = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var socket: WebSocket? = null
    private val _events = MutableSharedFlow<ChatEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<ChatEvent> = _events.asSharedFlow()

    fun connect(url: String) {
        disconnect()
        val request = Request.Builder().url(url).build()
        socket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                _events.tryEmit(ChatEvent.Connected)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                _events.tryEmit(ChatEvent.Message(text))
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                _events.tryEmit(ChatEvent.Disconnected(reason.ifBlank { "Terputus" }))
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                _events.tryEmit(ChatEvent.Disconnected(t.message ?: "Gagal terhubung"))
            }
        })
    }

    fun send(text: String): Boolean = socket?.send(text) ?: false

    fun disconnect() {
        socket?.close(1000, "bye")
        socket = null
    }
}
