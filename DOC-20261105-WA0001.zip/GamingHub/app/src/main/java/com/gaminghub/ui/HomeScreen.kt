package com.gaminghub.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gaminghub.Features

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Gaming Hub", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text("Status fitur:")
        Text(if (Features.HBG_ENABLED) "✅ HBG (Helper Boost Game): aktif" else "🔒 HBG")
        Text(if (Features.RECORDER_ENABLED) "✅ Recorder Layar" else "🔒 Recorder Layar: dikunci")
        Text(if (Features.CHAT_ENABLED) "✅ Chat" else "🔒 Chat: dikunci")
    }
}
