package com.gaminghub.hbg

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

enum class ShizukuState { OFF, NO_PERMISSION, READY }

/**
 * Menjalankan perintah shell lewat Shizuku (hak akses shell/ADB).
 * Catatan: Shizuku.newProcess bersifat private di API v13, jadi dipanggil lewat reflection.
 * Untuk jangka panjang sebaiknya pindah ke UserService (AIDL).
 */
object ShizukuShell {
    const val REQUEST_CODE = 1001

    data class Result(val code: Int, val out: String)

    fun state(): ShizukuState = try {
        when {
            !Shizuku.pingBinder() -> ShizukuState.OFF
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> ShizukuState.NO_PERMISSION
            else -> ShizukuState.READY
        }
    } catch (e: Throwable) {
        ShizukuState.OFF
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder() && !Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) {
        }
    }

    /** Panggil dari thread background. */
    fun exec(cmd: String): Result = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        Result(p.waitFor(), (out + err).trim())
    } catch (e: Throwable) {
        Result(-1, e.cause?.message ?: e.message ?: "error")
    }
}
