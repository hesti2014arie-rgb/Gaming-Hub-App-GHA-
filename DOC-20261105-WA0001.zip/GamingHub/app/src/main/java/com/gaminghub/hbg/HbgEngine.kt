package com.gaminghub.hbg

data class HbgSettings(
    val fpsBoost: Boolean = false,
    val antiAliasing: Boolean = false,
    val resolutionPercent: Int = 100,
    val forceCpu: Boolean = false,
    val gamePackage: String = ""
)

/**
 * Logika HBG lewat Shizuku. Semua perintah bisa dibatalkan lewat resetAll().
 * Hasil tiap perintah berbeda antar HP/versi Android (OEM bisa memblokir sebagian).
 */
object HbgEngine {
    private val PKG = Regex("^[A-Za-z0-9_.]+$")

    private class Log {
        val sb = StringBuilder()
        fun run(label: String, cmd: String) {
            val r = ShizukuShell.exec(cmd)
            val status = if (r.code == 0) "OK" else "gagal (${r.code})"
            sb.append("• ").append(label).append(": ").append(status)
            if (r.out.isNotBlank()) sb.append(" — ").append(r.out.take(100).replace('\n', ' '))
            sb.append('\n')
        }
    }

    fun apply(s: HbgSettings): String {
        val log = Log()
        val pkg = s.gamePackage.trim()
        val pkgOk = pkg.isNotEmpty() && PKG.matches(pkg)
        if (pkg.isNotEmpty() && !pkgOk) log.sb.append("• Package game tidak valid, dilewati\n")

        // Booster FPS: bersihkan proses latar + Game Mode performa (Android 12+)
        if (s.fpsBoost) {
            log.run("Bersihkan proses latar", "am kill-all")
            if (pkgOk) log.run("Game Mode performa ($pkg)", "cmd game mode performance $pkg")
        } else if (pkgOk) {
            log.run("Game Mode standar ($pkg)", "cmd game mode standard $pkg")
        }

        // Anti-aliasing: opsi developer "Force 4x MSAA" (hanya game OpenGL ES 2.0, perlu restart game)
        log.run("Force 4x MSAA ${if (s.antiAliasing) "ON" else "OFF"}", "setprop debug.egl.force_msaa ${s.antiAliasing}")

        // Paksa CPU: mode performa tetap (tidak semua HP mendukung)
        log.run("Mode performa tetap ${if (s.forceCpu) "ON" else "OFF"}", "cmd power set-fixed-performance-mode-enabled ${s.forceCpu}")

        // Resolusi
        if (s.resolutionPercent >= 100) {
            log.run("Reset resolusi", "wm size reset")
            log.run("Reset density", "wm density reset")
        } else {
            val size = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(ShizukuShell.exec("wm size").out)
            val dens = Regex("Physical density:\\s*(\\d+)").find(ShizukuShell.exec("wm density").out)
            if (size == null || dens == null) {
                log.sb.append("• Resolusi: gagal membaca ukuran layar asli\n")
            } else {
                val (w, h) = size.destructured
                val p = s.resolutionPercent
                val w2 = (w.toInt() * p / 100) / 2 * 2
                val h2 = (h.toInt() * p / 100) / 2 * 2
                val d2 = dens.groupValues[1].toInt() * p / 100
                log.run("Resolusi ${w2}x$h2", "wm size ${w2}x$h2")
                log.run("Density $d2", "wm density $d2")
            }
        }
        return log.sb.toString().trim()
    }

    /** Kembalikan semuanya ke normal. */
    fun resetAll(gamePackage: String = ""): String {
        val log = Log()
        log.run("Reset resolusi", "wm size reset")
        log.run("Reset density", "wm density reset")
        log.run("MSAA OFF", "setprop debug.egl.force_msaa false")
        log.run("Mode performa tetap OFF", "cmd power set-fixed-performance-mode-enabled false")
        val pkg = gamePackage.trim()
        if (pkg.isNotEmpty() && PKG.matches(pkg)) log.run("Game Mode standar ($pkg)", "cmd game mode standard $pkg")
        return log.sb.toString().trim()
    }
}
