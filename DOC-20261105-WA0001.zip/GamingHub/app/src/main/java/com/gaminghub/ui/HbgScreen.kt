package com.gaminghub.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.gaminghub.hbg.HbgEngine
import com.gaminghub.hbg.HbgSettings
import com.gaminghub.hbg.ShizukuShell
import com.gaminghub.hbg.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun batteryTempC(context: Context): Float? {
    val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
    val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
    return if (t < 0) null else t / 10f
}

@Composable
fun HbgScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showWarning by rememberSaveable { mutableStateOf(true) }
    var accepted by rememberSaveable { mutableStateOf(false) }
    var fps by rememberSaveable { mutableStateOf(false) }
    var aa by rememberSaveable { mutableStateOf(false) }
    var res by rememberSaveable { mutableIntStateOf(100) }
    var cpu by rememberSaveable { mutableStateOf(false) }
    var pkg by rememberSaveable { mutableStateOf("") }
    var result by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var temp by remember { mutableStateOf(batteryTempC(context)) }
    var shizuku by remember { mutableStateOf(ShizukuState.OFF) }

    LaunchedEffect(Unit) {
        while (true) {
            temp = batteryTempC(context)
            shizuku = ShizukuShell.state()
            delay(2000)
        }
    }

    if (showWarning) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("⚠️ Peringatan") },
            text = {
                Text(
                    "Aplikasi ini dapat memeras CPU agar berjalan lebih cepat, " +
                        "sehingga perangkat bisa menjadi panas. Jika tetap ingin memakainya, " +
                        "semua risiko ditanggung oleh pengguna."
                )
            },
            confirmButton = {
                TextButton(onClick = { accepted = true; showWarning = false }) { Text("Saya paham, lanjutkan") }
            },
            dismissButton = {
                TextButton(onClick = { accepted = false; showWarning = false }) { Text("Batal") }
            }
        )
    }

    val canRun = accepted && shizuku == ShizukuState.READY && !busy

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("HBG • Helper Boost Game", style = MaterialTheme.typography.headlineSmall)

        // Status suhu
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                val t = temp
                Text("🌡️ Suhu baterai: ${t?.let { "%.1f°C".format(it) } ?: "tidak diketahui"}")
                if (t != null && t >= 42f) {
                    Text(
                        "Perangkat panas. Matikan Paksa CPU dan istirahatkan HP.",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        // Status Shizuku
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                when (shizuku) {
                    ShizukuState.OFF -> Text("🔴 Shizuku tidak aktif. Install dan jalankan aplikasi Shizuku dulu.")
                    ShizukuState.NO_PERMISSION -> {
                        Text("🟡 Shizuku aktif, tapi app ini belum diberi izin.")
                        Button(onClick = { ShizukuShell.requestPermission() }) { Text("Minta izin Shizuku") }
                    }
                    ShizukuState.READY -> Text("🟢 Shizuku siap")
                }
            }
        }

        if (!accepted) {
            Text("Fitur dikunci sampai kamu menyetujui peringatan.")
            Button(onClick = { showWarning = true }) { Text("Tampilkan peringatan") }
        }

        OutlinedTextField(
            value = pkg,
            onValueChange = { pkg = it },
            label = { Text("Package game (opsional)") },
            placeholder = { Text("contoh: com.mobile.legends") },
            singleLine = true,
            enabled = accepted,
            modifier = Modifier.fillMaxWidth()
        )

        SwitchRow("Booster FPS", "Bersihkan proses latar + Game Mode performa", fps, accepted) { fps = it }
        SwitchRow("Anti-aliasing", "Force 4x MSAA (game OpenGL ES 2.0, restart game)", aa, accepted) { aa = it }

        Text("Resolusi")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(100, 85, 70, 50).forEach { p ->
                FilterChip(selected = res == p, onClick = { res = p }, label = { Text("$p%") }, enabled = accepted)
            }
        }

        SwitchRow("Paksa CPU (berisiko panas)", "Mode performa tetap, CPU bekerja lebih keras", cpu, accepted) { cpu = it }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = canRun,
                onClick = {
                    scope.launch {
                        busy = true
                        result = withContext(Dispatchers.IO) {
                            HbgEngine.apply(HbgSettings(fps, aa, res, cpu, pkg))
                        }
                        busy = false
                    }
                }
            ) { Text(if (busy) "Memproses..." else "Terapkan") }

            OutlinedButton(
                enabled = shizuku == ShizukuState.READY && !busy,
                onClick = {
                    scope.launch {
                        busy = true
                        result = withContext(Dispatchers.IO) { HbgEngine.resetAll(pkg) }
                        fps = false; aa = false; cpu = false; res = 100
                        busy = false
                    }
                }
            ) { Text("Reset semua") }
        }

        if (result.isNotEmpty()) Text(result, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SwitchRow(
    title: String,
    desc: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(desc, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
